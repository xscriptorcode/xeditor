import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:docx_template/docx_template.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' as syncfusion;

class DocumentService {
  static Future<Map<String, String?>> saveDocument(
      String text, String? filePath, String documentName, String fileFormat) async {
    final json = jsonEncode({'content': text});

    if (filePath != null) {
      final file = File(filePath);
      await file.writeAsString(json);
      return {'path': filePath, 'name': documentName, 'format': fileFormat};
    } else {
      return await saveAs(text);
    }
  }

  static Future<Map<String, String?>> saveAs(String text) async {
    final json = jsonEncode({'content': text});

    String? outputFilePath = await FilePicker.platform.saveFile(
      dialogTitle: 'Guardar documento como',
      fileName: 'MiDocumento',
      allowedExtensions: ['json'],
      type: FileType.custom,
    );

    if (outputFilePath != null) {
      final file = File(outputFilePath);
      await file.writeAsString(json);

      return {
        'path': outputFilePath,
        'name': outputFilePath.split('/').last.split('.').first,
        'format': ".json"
      };
    }
    return {};
  }

  static Future<Map<String, String?>> saveAsDocx(String text) async {
    final docxTemplate = await rootBundle.load('assets/template.docx');
    final bytes = docxTemplate.buffer.asUint8List();
    final docx = await DocxTemplate.fromBytes(bytes);

    Content content = Content();
    content.add(TextContent('header', text));

    final docGenerated = await docx.generate(content);
    if (docGenerated != null) {
      String? outputFilePath = await FilePicker.platform.saveFile(
        dialogTitle: 'Guardar documento como DOCX',
        fileName: 'MiDocumento',
        allowedExtensions: ['docx'],
        type: FileType.custom,
      );

      if (outputFilePath != null) {
        final file = File(outputFilePath);
        await file.writeAsBytes(docGenerated);

        return {
          'path': outputFilePath,
          'name': outputFilePath.split('/').last.split('.').first,
          'format': ".docx"
        };
      }
    }
    return {};
  }

  static Future<Map<String, String?>> saveAsPdf(String text) async {
    final pdf = syncfusion.PdfDocument();
    final page = pdf.pages.add();
    page.graphics.drawString(
      text,
      syncfusion.PdfStandardFont(syncfusion.PdfFontFamily.helvetica, 12),
      bounds: Rect.fromLTWH(0, 0, page.getClientSize().width, page.getClientSize().height),
    );

    String? outputFilePath = await FilePicker.platform.saveFile(
      dialogTitle: 'Guardar documento como PDF',
      fileName: 'MiDocumento',
      allowedExtensions: ['pdf'],
      type: FileType.custom,
    );

    if (outputFilePath != null) {
      final file = File(outputFilePath);
      await file.writeAsBytes(pdf.saveSync());
      pdf.dispose();

      return {
        'path': outputFilePath,
        'name': outputFilePath.split('/').last.split('.').first,
        'format': ".pdf"
      };
    }
    return {};
  }

  static Future<Map<String, String?>> openDocument() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json', 'docx', 'pdf']);
    if (result != null && result.files.single.path != null) {
      final file = File(result.files.single.path!);
      final extension = result.files.single.extension;

      if (extension == 'json') {
        final jsonString = await file.readAsString();
        final content = jsonDecode(jsonString)['content'];
        return {
          'path': result.files.single.path,
          'name': result.files.single.name.split('.').first,
          'format': ".json",
          'content': content,
        };
      }
    }
    return {};
  }
}

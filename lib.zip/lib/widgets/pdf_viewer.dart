import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart' as pdfx;

void openPdfViewer(BuildContext context, pdfx.PdfController pdfController) {
  Navigator.of(context).push(
    MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: Text("Vista de PDF")),
        body: pdfx.PdfView(controller: pdfController),
      ),
    ),
  );
}

import 'package:flutter/material.dart';
import 'editor_layout.dart';
import 'editor_controller.dart';
import 'document_manager.dart';
import 'pdf_viewer.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;


class EditorArea extends StatefulWidget {
  @override
  _EditorAreaState createState() => _EditorAreaState();
}

class _EditorAreaState extends State<EditorArea> {
  late EditorController _editorController;
  late DocumentManager _documentManager;

  @override
  void initState() {
    super.initState();
    _editorController = EditorController();
    _documentManager = DocumentManager(_editorController);
  }

  @override
  void dispose() {
    _editorController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return EditorLayout(
      editorController: _editorController,
      customButtons: [
        quill.QuillToolbarCustomButtonOptions(
          icon: Icon(Icons.save),
          tooltip: 'Guardar',
          onPressed: _documentManager.saveDocument,
        ),
        quill.QuillToolbarCustomButtonOptions(
          icon: Icon(Icons.save_as),
          tooltip: 'Guardar como DOCX',
          onPressed: _documentManager.saveDocumentAsDocx,
        ),
        quill.QuillToolbarCustomButtonOptions(
          icon: Icon(Icons.picture_as_pdf),
          tooltip: 'Guardar como PDF',
          onPressed: _documentManager.saveDocumentAsPdf,
        ),
        quill.QuillToolbarCustomButtonOptions(
          icon: Icon(Icons.folder_open),
          tooltip: 'Abrir',
          onPressed: _documentManager.openDocument,
        ),
      ],
      onOpenPdfViewer: () => openPdfViewer(context, _editorController.pdfController),
    );
  }
}
